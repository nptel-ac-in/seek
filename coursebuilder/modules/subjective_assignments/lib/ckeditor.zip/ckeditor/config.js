/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
config.toolbar = [
  { name: 'document', groups: [ 'mode', 'doctools' ], items: [ 'Source', '-', 'Templates' ] },
  { name: 'clipboard', groups: [ 'undo' ], items: [ 'Undo', 'Redo' ] },
  { name: 'styles', items: [ 'Format', 'Font', 'FontSize' ] },
  { name: 'colors', items: [ 'TextColor', 'BGColor' ] },
  { name: 'tools', items: [ 'Maximize'] },
  { name: 'about', items: [ 'About'] },
  '/',
  { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ], items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat' ] },
  { name: 'paragraph', groups: [ 'list', 'indent', 'align'], items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock'] },
  { name: 'links', items: [ 'Link', 'Unlink' ] },
  { name: 'insert', items: [ 'Table', 'HorizontalRule', 'SpecialChar'] },
  { name: 'editing', groups: [ 'spellchecker' ], items: [ 'Scayt' ] },
];

// Toolbar groups configuration.
config.toolbarGroups = [
  { name: 'document', groups: [ 'mode', 'doctools' ] },
  { name: 'clipboard', groups: [ 'undo' ] },
  { name: 'styles' },
  { name: 'colors' },
  { name: 'tools' },
  { name: 'about' },
  '/',
  { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
  { name: 'paragraph', groups: [ 'list', 'indent', 'align' ] },
  { name: 'links' },
  { name: 'insert' },
  { name: 'editing', groups: [ 'spellchecker' ] },
];

};
