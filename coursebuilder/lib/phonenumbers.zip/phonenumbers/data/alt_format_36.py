"""Auto-generated file, do not edit by hand. 36 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_36 = [NumberFormat(pattern='(1)(\\d{4})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['1']), NumberFormat(pattern='(\\d{2})(\\d{4})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['[2-9]'])]
