version_info = (3, 6, 3)
__version__ = '.'.join(str(v) for v in version_info)
