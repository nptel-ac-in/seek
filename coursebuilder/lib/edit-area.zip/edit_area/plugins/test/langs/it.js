editArea.add_lang("it",{
test_select: "seleziona tag",
test_but: "pulsante di test"
});
