version_info = (3, 1, 10)
__version__ = '.'.join(str(v) for v in version_info)
